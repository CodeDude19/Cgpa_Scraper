# import selenium
# from selenium import webdriver
# webpage = r"https://results.smu.edu.in/smit/results_search.php?exam=49"
# driver = webdriver.Chrome("C:\\Users\\Yasser\\Downloads\\chromedriver_win32\\chromedriver.exe")
# driver.get(webpage)
# sbox = driver.find_element_by_id("regno")
# searchterm = "201700063"
# sbox.send_keys(searchterm)
# submit = driver.find_element_by_class_name("button_cont")
# submit.click()
# selecterLink = driver.find_element_by_xpath('//a[@href="'+"results_details.php?sem=4"+'"]')
# selecterLink.click()
# divList = driver.find_elements_by_class_name("result-dtl2")
# divList[1].get_attribute('innerHTML') 
# regNo = driver.find_element_by_class_name("result-dtl")
# regNo[0].get_attribute('innerHTML') #Reg no
# regNo[1].get_attribute('innerHTML') #Name

# Creating Scraper : 
import selenium
from selenium import webdriver
